﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void prijaviradnika()
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Morate popuniti sva polja");
            }
            else
            {
                SqlConnection con = new SqlConnection("data source =AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
                SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) FROM korisnik WHERE KorisnickoIme = '" + textBox1.Text + "' AND sifra = '" + textBox2.Text + "' AND tip = 'R'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1")
                {
                    this.Hide();
                    Radnik rd = new Radnik();
                    rd.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Uneli ste pogresno ime ili lozinku");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            prijaviradnika();        
        }
        private void prijavinadleznog()
        {
             if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Morate popuniti sva polja");
            }
            else
            {
                SqlConnection con = new SqlConnection("data source = AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
                SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) FROM korisnik WHERE KorisnickoIme = '" + textBox1.Text + "' AND sifra = '" + textBox2.Text + "' AND tip = 'N'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                {
                    this.Hide();
                    Nadlezni nd = new Nadlezni();
                    nd.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Uneli ste pogresno ime ili lozinku");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            prijavinadleznog();
        }

        private void promenaLozinke_Click(object sender, EventArgs e)
        {
            promenaLozinke pl = new promenaLozinke();
            pl.ShowDialog();
        }

        private void izadji_Click(object sender, EventArgs e)
        {
            this.Close();
        }     

        private void cbPrikaziLozinku_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = cbPrikaziLozinku.Checked ? '\0' : '*';
        }
    }
}

