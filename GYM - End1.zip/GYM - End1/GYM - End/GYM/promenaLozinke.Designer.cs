﻿namespace GYM
{
    partial class promenaLozinke
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txbKorisnickoIme = new System.Windows.Forms.TextBox();
            this.txbLozinka = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txbNovaLozinka = new System.Windows.Forms.TextBox();
            this.txbPotvrdaLozinke = new System.Windows.Forms.TextBox();
            this.cbLozinka = new System.Windows.Forms.CheckBox();
            this.btnPPonisti = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 50);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Korisnicko ime:";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(51, 97);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Stara lozinka:";
            // 
            // txbKorisnickoIme
            // 
            this.txbKorisnickoIme.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbKorisnickoIme.Location = new System.Drawing.Point(221, 49);
            this.txbKorisnickoIme.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbKorisnickoIme.Name = "txbKorisnickoIme";
            this.txbKorisnickoIme.Size = new System.Drawing.Size(184, 22);
            this.txbKorisnickoIme.TabIndex = 2;
            // 
            // txbLozinka
            // 
            this.txbLozinka.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbLozinka.Location = new System.Drawing.Point(221, 96);
            this.txbLozinka.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbLozinka.Name = "txbLozinka";
            this.txbLozinka.PasswordChar = '*';
            this.txbLozinka.Size = new System.Drawing.Size(184, 22);
            this.txbLozinka.TabIndex = 2;
            this.txbLozinka.Tag = "";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(31, 277);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 44);
            this.button1.TabIndex = 3;
            this.button1.Text = "Promeni lozinku";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(51, 142);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Nova lozinka:";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(51, 186);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Potvrdi lozinku:";
            // 
            // txbNovaLozinka
            // 
            this.txbNovaLozinka.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbNovaLozinka.Location = new System.Drawing.Point(221, 140);
            this.txbNovaLozinka.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbNovaLozinka.Name = "txbNovaLozinka";
            this.txbNovaLozinka.PasswordChar = '*';
            this.txbNovaLozinka.Size = new System.Drawing.Size(184, 22);
            this.txbNovaLozinka.TabIndex = 2;
            this.txbNovaLozinka.Tag = "";
            // 
            // txbPotvrdaLozinke
            // 
            this.txbPotvrdaLozinke.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbPotvrdaLozinke.Location = new System.Drawing.Point(221, 185);
            this.txbPotvrdaLozinke.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbPotvrdaLozinke.Name = "txbPotvrdaLozinke";
            this.txbPotvrdaLozinke.PasswordChar = '*';
            this.txbPotvrdaLozinke.Size = new System.Drawing.Size(184, 22);
            this.txbPotvrdaLozinke.TabIndex = 2;
            this.txbPotvrdaLozinke.Tag = "";
            // 
            // cbLozinka
            // 
            this.cbLozinka.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbLozinka.AutoSize = true;
            this.cbLozinka.Location = new System.Drawing.Point(221, 217);
            this.cbLozinka.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbLozinka.Name = "cbLozinka";
            this.cbLozinka.Size = new System.Drawing.Size(120, 21);
            this.cbLozinka.TabIndex = 4;
            this.cbLozinka.Text = "Prikazi lozinku";
            this.cbLozinka.UseVisualStyleBackColor = true;
            this.cbLozinka.CheckedChanged += new System.EventHandler(this.cbLozinka_CheckedChanged);
            // 
            // btnPPonisti
            // 
            this.btnPPonisti.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPPonisti.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPPonisti.Location = new System.Drawing.Point(281, 277);
            this.btnPPonisti.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPPonisti.Name = "btnPPonisti";
            this.btnPPonisti.Size = new System.Drawing.Size(141, 44);
            this.btnPPonisti.TabIndex = 5;
            this.btnPPonisti.Text = "Ponisti";
            this.btnPPonisti.UseVisualStyleBackColor = true;
            this.btnPPonisti.Click += new System.EventHandler(this.btnPPonisti_Click);
            // 
            // promenaLozinke
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(480, 356);
            this.Controls.Add(this.btnPPonisti);
            this.Controls.Add(this.cbLozinka);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txbPotvrdaLozinke);
            this.Controls.Add(this.txbNovaLozinka);
            this.Controls.Add(this.txbLozinka);
            this.Controls.Add(this.txbKorisnickoIme);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "promenaLozinke";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "promenaLozinke";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txbKorisnickoIme;
        private System.Windows.Forms.TextBox txbLozinka;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txbNovaLozinka;
        private System.Windows.Forms.TextBox txbPotvrdaLozinke;
        private System.Windows.Forms.CheckBox cbLozinka;
        private System.Windows.Forms.Button btnPPonisti;
    }
}