﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GYM
{
    public partial class cenovnikk : UserControl
    {
        GymEntities10 vezasaBazom;
        string vr_old = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss ");
        public cenovnikk()
        {
            InitializeComponent();
            vezasaBazom = new GymEntities10();
            var sve = vezasaBazom.cenovniks.ToList();
            var napisi = sve.ElementAt(0).poslednjePromene;
            textBox5.Text = napisi;
        }
        private void cene()
        {
            SqlConnection con = new SqlConnection("data source=AMINA;initial catalog=Gym;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From cenovnik ;", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                textBox1.Text = dt.Rows[0][0].ToString();
                textBox2.Text = dt.Rows[1][0].ToString();
                textBox3.Text = dt.Rows[2][0].ToString();
                textBox4.Text = dt.Rows[3][0].ToString();
            }
            else
            {
                MessageBox.Show("Proverite");
            }
        }
        private void cenovnikk_Load(object sender, EventArgs e)
        {
            cene();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("data source=AMINA;initial catalog=Gym;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;");
            try
            {
                con.Open();
                String vr_new = DateTime.Now.ToString("dddd, dd MMMM yyyy HH:mm");
                vr_old = vr_new;
                SqlCommand sda = new SqlCommand("Update cenovnik set cena =" + textBox1.Text + " where tip = 'MG';Update cenovnik set cena =" + textBox2.Text + " where tip= 'MI';Update cenovnik set cena =" + textBox3.Text + " where tip= 'GT'; Update cenovnik set cena =" + textBox4.Text + " where tip= 'IT'; Update cenovnik set poslednjePromene='"+vr_new+"';", con);
                sda.ExecuteNonQuery();
                MessageBox.Show("Uspesno");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
