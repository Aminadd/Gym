﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GYM
{
    public partial class clanovi : UserControl
    {
        GymEntities10 vezasaBazom;
        public clanovi()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            vezasaBazom = new GymEntities10();
            popuniTabelu();

        }

        private void popuniTabelu()
        {
            var prikazati = " ";

            var clanovi = new List<string>();
            List<osoba> lista = vezasaBazom.osobas.ToList();
            List<clan> lista2 = vezasaBazom.clans.ToList();
            List<string> zaPrikaz = new List<string>();

            foreach (var osoba in lista)
            {
                foreach (var cl in lista2)
                {
                    if (osoba.JMBG == cl.IDClana)
                    {
                   prikazati = osoba.Ime + " " + osoba.Prezime + " " + osoba.brTelefona + " " + osoba.adresa + " " + osoba.email + " " + osoba.pol + " " + cl.datumRodj + " " + cl.datumUpisa + " " + osoba.JMBG;

                        zaPrikaz.Add(prikazati);

                    }

                    else
                    {
                        continue;
                    }
                }
            }

            LBoxPrikazi.DataSource = zaPrikaz;
        }

        private void clanovi_Load(object sender, EventArgs e)
        {

        }
        private void dodajclana()
        {
            if (tbIme.Text == "" || tbPrezime.Text == "" || tbbrTelefona.Text == "" || tbAdresa.Text == "" || tbemail.Text == "" || tbJMBG.Text == "")
            {
                MessageBox.Show("Morate popuniti sva polja!");
            }
            else
            {
                SqlConnection con = new SqlConnection("data source = AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
                try
                {
                    con.Open();
                    string res = "";
                    if (rbM.Checked)
                        res = "M";
                    else
                        res = "Ž";
                    SqlCommand sda = new SqlCommand("Insert into osoba (Ime,Prezime,brTelefona,adresa,email,JMBG,pol) values('" + tbIme.Text + "','" + tbPrezime.Text + "','" + tbbrTelefona.Text + "','" + tbAdresa.Text + "','" + tbemail.Text + "','" + tbJMBG.Text + "','" + res + "'); INSERT INTO clan( IDclana,datumRodj,datumUpisa) values('" + tbJMBG.Text + "','" + dtpdatumrodj.Text + "','" + dtpdatumup.Text + "');", con);
                    sda.ExecuteNonQuery();
                    MessageBox.Show("Uspešno");
                    con.Close();

                }
                catch 
                {
                    MessageBox.Show("Član vec postoji !");
                }

            }

        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            dodajclana();
        }
        private void promenipodatke()
        {
            SqlConnection con = new SqlConnection("data source =AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
            try
            {
                con.Open();
                SqlCommand sda = new SqlCommand("UPDATE osoba SET  brTelefona='" + tbbrTelefona.Text + "',adresa='" + tbAdresa.Text + "',email='" + tbemail.Text + "' WHERE JMBG='" + tbJMBG.Text + "'; UPDATE clan SET  datumUpisa='" + dtpdatumup.Text + "' WHERE IDClana='" + tbJMBG.Text + "'", con);
                sda.ExecuteNonQuery();
                MessageBox.Show("Uspešno");
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            promenipodatke();
        }

        private void izbrisiclana() {

            DialogResult Izlaz;
            Izlaz = MessageBox.Show("Da li želite da izbrišete člana?", "Izlaz", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (Izlaz == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection("data source =AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
                try
                {
                    con.Open();
                    SqlCommand sda = new SqlCommand("DELETE FROM rezultati where JMBG1='" + tbJMBG.Text + "';DELETE FROM clan where IDClana='" + tbJMBG.Text + "';Delete from  osoba where Ime='" + tbIme.Text + "' and Prezime='" + tbPrezime.Text + "' and JMBG='" + tbJMBG.Text + "'", con);

                    sda.ExecuteNonQuery();
                    MessageBox.Show("Uspešno");
                    con.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            izbrisiclana();
        }

        private void btnPretrazi_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbPretraga.Text == "")
                {
                    MessageBox.Show("Unesite ime i prezime za pretragu");

                }
                else
                {
                    var imee = "";
                    var prezimee = "";
                    var uneto = "";
                    var uneseno = tbPretraga.Text;
                    try
                    {
                        string[] unosi = uneseno.Split(' ');
                        imee = unosi[0];
                        prezimee = unosi[1];
                    }
                    catch
                    {
                        uneto = tbPretraga.Text;
                    }
                    var osobe = vezasaBazom.osobas.ToList();
                    var clanovi = vezasaBazom.clans.ToList();
                    var lista = new List<string>();
                    var trazena = " ";
                    foreach (var osoba in osobe)
                    {
                        foreach (var clan in clanovi)
                        {
                            if ((osoba.Ime == uneto && osoba.JMBG == clan.IDClana) || (osoba.Prezime == uneto && osoba.JMBG == clan.IDClana) || (osoba.Ime == imee && osoba.Prezime == prezimee && osoba.JMBG == clan.IDClana))
                            {
                                trazena = osoba.Ime + " " + osoba.Prezime + " " + osoba.brTelefona + " " + osoba.adresa + " " + osoba.email + " " + osoba.pol + " " + clan.datumRodj + " " + clan.datumUpisa + " " + osoba.JMBG;
                                lista.Add(trazena);
                            }
                        }
                    }
                    LBoxPrikazi.DataSource = lista;
                }          
            }
            catch
            {
                MessageBox.Show("Nije pronadjena osoba");
            }

        }

        private void LBoxPrikazi_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("data source=AMINA;initial catalog=Gym;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From osoba;", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                tbIme.Text = dt.Rows[0][0].ToString();
                tbPrezime.Text = dt.Rows[0][1].ToString();
                tbbrTelefona.Text = dt.Rows[0][2].ToString();
                tbAdresa.Text = dt.Rows[0][3].ToString();
                tbemail.Text = dt.Rows[0][4].ToString();
                tbJMBG.Text = dt.Rows[0][6].ToString();

            }
            else
            {
                MessageBox.Show("Proverite JMBG");
            }

            SqlDataAdapter sde = new SqlDataAdapter("Select * From osoba;", con);
            DataTable dtt = new DataTable();
            sda.Fill(dtt);
        }

        private void LBoxPrikazi_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LBoxPrikazi.SelectedItem == null)
            {
                return;
            }
            else
            {

                var izabran = LBoxPrikazi.SelectedItem.ToString();
                string[] unosi = izabran.Split(' ');
                var ime = unosi[0];
                var prezime = unosi[1];
                var brojt = unosi[2];
                var adresa1 = unosi[3];
                var adresa2 = unosi[4];
                var email = unosi[5];
                var pol = unosi[6];
                var jmbg = unosi[9];
                var adresa = adresa1 + " " + adresa2;


                tbIme.Text = ime;
                tbPrezime.Text = prezime;
                tbemail.Text = email;
                tbbrTelefona.Text = brojt;
                tbAdresa.Text = adresa;
                tbJMBG.Text = jmbg;
            }
        }
        private void brnocisti_Click(object sender, EventArgs e)
        {
            tbIme.Text = "";
            tbPrezime.Text = "";
            tbJMBG.Text = "";
            tbemail.Text = "";
            tbbrTelefona.Text = "";
            tbAdresa.Text = "";
        }
    }
}
