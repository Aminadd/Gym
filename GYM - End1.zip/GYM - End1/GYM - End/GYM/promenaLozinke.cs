﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM
{
    public partial class promenaLozinke : Form
    {
        GymEntities10 veza = new GymEntities10();
        public promenaLozinke()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txbKorisnickoIme.Text == "" || txbLozinka.Text == "" || txbNovaLozinka.Text == "" || txbPotvrdaLozinke.Text == "")
                {
                    MessageBox.Show("Morate popuniti sva polja");
                }
                else
                {
                    List<korisnik> korisnici = veza.korisniks.ToList();

                    int zadati = korisnici.Where(x => x.KorisnickoIme == txbKorisnickoIme.Text && x.sifra == txbLozinka.Text).Count();//broj korisnka u bazi za koje je korisnicko ime

                    var kori = korisnici.Where(x => x.KorisnickoIme == txbKorisnickoIme.Text).ToList();

                    foreach (var k in kori)
                    {
                        if (txbNovaLozinka.Text.Equals(txbPotvrdaLozinke.Text))
                        {
                            k.sifra = txbNovaLozinka.Text;
                            veza.SaveChanges();
                            this.Close();
                            MessageBox.Show("Promenili ste lozinku");
                        }
                        else
                        {
                            MessageBox.Show("Proverite lozinke.  Niste uneli iste lozinke.");
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnPPonisti_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f = new Form1();
            f.Show();
        }

        private void cbLozinka_CheckedChanged(object sender, EventArgs e)
        {
            txbLozinka.PasswordChar = cbLozinka.Checked ? '\0' : '*';

            txbNovaLozinka.PasswordChar = cbLozinka.Checked ? '\0' : '*';

            txbPotvrdaLozinke.PasswordChar = cbLozinka.Checked ? '\0' : '*';
        }
    }
}
