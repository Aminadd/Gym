﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GYM
{
    public partial class rezultat : UserControl
    {
        string visina_old, tezina_old, ruke_old, noge_old, struk_old;
        string vremeUnosa_old_string;

        GymEntities10 vezasaBazom;
        public rezultat()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            vezasaBazom = new GymEntities10();
            textBox1.Text = DateTime.Now.ToString("MM/dd/yyyy  HH:mm:ss");
            popuniTabelu();
        }
       
        private void popuniTabelu()
        {
            var prikazati = " ";

            List<rezultati> lista = vezasaBazom.rezultatis.ToList();
            List<string> zaPrikaz = new List<string>();
            foreach (var cl in lista) {

                prikazati = cl.ime + " " + cl.visina + " " +cl.tezina + " " + cl.ruke+ " " + cl.noge + " " + cl.struk + " " + cl.JMBG1 + " " + cl.vremeUnosa ;

                zaPrikaz.Add(prikazati);
            }
            listBox1.DataSource = zaPrikaz;
        }

        private void btnOcisti_Click(object sender, EventArgs e)
        {
            tbImeiPrezime.Text = "";
            tbnoge.Text = "";
            tbruke.Text = "";
            tbstruk.Text = "";
            tbvisina.Text = "";
            txtTezina.Text = "";
            jmbg.Text = "";
            textBox1.Text = "";
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("data source=AMINA;initial catalog=Gym;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From rezultati;", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                tbImeiPrezime.Text = dt.Rows[0][0].ToString();
                tbvisina.Text = dt.Rows[0][2].ToString();
                txtTezina.Text = dt.Rows[0][3].ToString();
                tbruke.Text = dt.Rows[0][4].ToString();
                tbnoge.Text = dt.Rows[0][6].ToString();
                tbstruk.Text = dt.Rows[0][7].ToString();
                jmbg.Text = dt.Rows[0][8].ToString();
                textBox1.Text = dt.Rows[0][9].ToString();

            }
            else
            {
                MessageBox.Show("Proverite JMBG");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {       
            SqlConnection con = new SqlConnection("data source =AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
            try
            {
                con.Open();
                String vr_new = DateTime.Now.ToString("dd MMMM yyyy HH:mm");
                SqlCommand sda = new SqlCommand("Insert into rezultati (ime,visina,tezina,ruke,noge,JMBG1,struk, vremeUnosa, visina_epic,tezina_epic, ruke_epic, noge_epic, struk_epic, vremeUnosa_epic) values('" + tbImeiPrezime.Text + "','" + tbvisina.Text + "','" + txtTezina.Text + "','" + tbruke.Text + "','" + tbnoge.Text + "','" + jmbg.Text + "','"+tbstruk.Text+"' , '" + vr_new+"','0', '0', '0', '0', '0', '0');", con);
                sda.ExecuteNonQuery();
                MessageBox.Show("Uspešno");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("data source=AMINA;initial catalog=Gym;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From rezultati where JMBG1='" + jmbg.Text + "' ;", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                visina_old = dt.Rows[0][0].ToString();
                tezina_old = dt.Rows[0][1].ToString();
                ruke_old = dt.Rows[0][2].ToString();
                noge_old = dt.Rows[0][3].ToString();
                struk_old = dt.Rows[0][4].ToString();
          
                vremeUnosa_old_string = dt.Rows[0][11].ToString();
            }
            else
            {
                MessageBox.Show("Proverite JMBG");
            }

            try
            {
                con.Open();
                SqlCommand sdaa = new SqlCommand("Update rezultati set visina_epic ='" + visina_old + "', tezina_epic ='" + tezina_old + "', ruke_epic='" + ruke_old + "', noge_epic ='" + noge_old + "', struk_epic='" + struk_old + "',vremeUnosa_epic='" + vremeUnosa_old_string + "' where JMBG1='" + jmbg.Text + "';", con);
                sdaa.ExecuteNonQuery();
                MessageBox.Show("Uspesno");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            SqlConnection conn = new SqlConnection("data source=DESKTOP-L1JRQG0;initial catalog=Gym;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;");
            try
            {
                con.Open();
                string vr = DateTime.Now.ToString("MM/dd/yyyy  HH:mm:ss");
                SqlCommand sdaa = new SqlCommand("Update rezultati set ime='" + tbImeiPrezime.Text + "', vremeUnosa ='" + vr +"', visina='" + tbvisina.Text +"', tezina='" + txtTezina.Text + "', ruke='" + tbruke.Text + "', noge='" + tbnoge.Text + "', struk='" + tbstruk.Text +"' WHERE JMBG1='" +jmbg.Text + "'", con);
                sdaa.ExecuteNonQuery();
                MessageBox.Show("Uspesno");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var izabran = listBox1.SelectedItem.ToString();
            string[] unosi = izabran.Split(' ');
            var ime = unosi[0];
            var prezime = unosi[1];
            var imeiprezime = ime + " " + prezime;
            var visina = unosi[2];
            var tezina = unosi[3];
            var ruke = unosi[4];
            var noge = unosi[5];
            var struk = unosi[6];
            var jmbg11 = unosi[7];
            var vrUnosa1 = unosi[8];
           var vrUnosa2 = unosi[9];
            var vrUnosa = vrUnosa1+ " "+vrUnosa2 ;

            tbImeiPrezime.Text = imeiprezime;
            tbvisina.Text = visina;
            txtTezina.Text = tezina;
            tbruke.Text = ruke;
            tbnoge.Text = noge;
            tbstruk.Text = struk;
            jmbg.Text = jmbg11;
            textBox1.Text = vrUnosa;
        }     
    }
}
