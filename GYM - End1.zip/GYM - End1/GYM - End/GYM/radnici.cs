﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GYM
{
    public partial class radnici : UserControl
    {
        GymEntities10 vezasaBazom;
        public radnici()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            vezasaBazom = new GymEntities10();
            popuniTabelu();
        }

        private void popuniTabelu()
        {
            var radnici = new List<osoba>();
            List<osoba> lista = vezasaBazom.osobas.ToList();
            List<korisnik> lista2 = vezasaBazom.korisniks.Where(t => t.tip == "R").ToList();

            foreach (var osoba in lista)
            {
                foreach (var kor in lista2)
                {
                    if (osoba.JMBG == kor.IDKorisnika)
                    {
                        radnici.Add(osoba);
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            var zaPrikaz = new List<string>();
            foreach (var r in radnici)
            {
                zaPrikaz.Add(r.ToString());
            }
            radniciBox.DataSource = zaPrikaz;
        }

        private void dodavanje() {
            if (tbIme.Text == "" || tbPrezime.Text == "" || tbbrTel.Text == "" || tbadresa.Text == "" || tbemail.Text == "" || tbJMBG.Text == "")
            {
                MessageBox.Show("Morate popuniti sva polja!");
            }
            else
            {
                SqlConnection con = new SqlConnection("data source =AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
                try
                {
                    con.Open();
                    string res = "";
                    if (cbM.Checked)
                        res = "M";
                    else
                        res = "Ž";
                    SqlCommand sda = new SqlCommand("Insert into osoba (Ime,Prezime,brTelefona,adresa,email,JMBG,pol) values('" + tbIme.Text + "','" + tbPrezime.Text + "','" + tbbrTel.Text + "','" + tbadresa.Text + "','" + tbemail.Text + "','" + tbJMBG.Text + "','" + res + "'); INSERT INTO korisnik( IDkorisnika,sifra,KorisnickoIme,tip) values('" + tbJMBG.Text + "','" + txtLozinka.Text + "','" + tbKorisnickoIme.Text + "','R');", con);
                    sda.ExecuteNonQuery();
                    MessageBox.Show("Uspešno");
                    con.Close();

                }
                catch
                {
                    MessageBox.Show("Radnik vec postoji u bazi");
                }
            }
        }
        private void btnDodaj_Click(object sender, EventArgs e)
        {
            dodavanje();
        }

        private void brisanje()
        {
            DialogResult Izlaz;
            Izlaz = MessageBox.Show("Da li želite da izbrišete člana?", "Izlaz", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (Izlaz == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection("data source =AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
                try
                {
                    con.Open();
                    SqlCommand sda = new SqlCommand("DELETE FROM korisnik where IDKorisnika='" + tbJMBG.Text + "';Delete from  osoba where Ime='" + tbIme.Text + "' and Prezime='" + tbPrezime.Text + "' and JMBG='" + tbJMBG.Text + "'", con);

                    sda.ExecuteNonQuery();
                    MessageBox.Show("Uspešno");
                    con.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void btnObrisi_Click(object sender, EventArgs e)
        {
            brisanje();
        }

        private void promeni()
        {
            if (tbbrTel.Text == "" || tbadresa.Text == "" || tbemail.Text == "" || tbJMBG.Text == "")
            {
                MessageBox.Show("Morate uneti broj telefona, adresu i email.");
            }
            else
            {
                SqlConnection con = new SqlConnection("data source =AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
                try
                {
                    con.Open();
                    SqlCommand sda = new SqlCommand("UPDATE osoba SET brTelefona='" + tbbrTel.Text + "',adresa='" + tbadresa.Text + "',email='" + tbemail.Text + "' WHERE JMBG='" + tbJMBG.Text + "';", con);
                    sda.ExecuteNonQuery();
                    MessageBox.Show("Uspešno");
                    con.Close();

                }
                 catch (Exception ex)
                 {
                      MessageBox.Show(ex.Message);
                 }
           } 
        }

        private void btnAzuriranje_Click(object sender, EventArgs e)
        {
            promeni();
        }

        private void radniciBox_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("data source=AMINA;initial catalog=Gym;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From osoba;", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                tbIme.Text = dt.Rows[0][0].ToString();
                tbPrezime.Text = dt.Rows[0][1].ToString();
                tbbrTel.Text = dt.Rows[0][2].ToString();
                tbadresa.Text = dt.Rows[0][3].ToString();
                tbemail.Text = dt.Rows[0][4].ToString();
                tbJMBG.Text = dt.Rows[0][6].ToString();

            }
            else
            {
                MessageBox.Show("Proverite JMBG");
            }
        }

        private void radniciBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var izabran = radniciBox.SelectedItem.ToString();
            string[] unosi = izabran.Split(' ');
            var jmbg = unosi[0];
            var ime = unosi[1];
            var prezime = unosi[2];
            var email = unosi[3];
            var pol = unosi[4];
            var adresa1 = unosi[5];
            var adresa2 = unosi[6];
            var brojt = unosi[7];
            var adresa = adresa1 + " " + adresa2;

            tbIme.Text = ime;
            tbPrezime.Text = prezime;
            tbemail.Text = email;
            tbbrTel.Text = brojt;
            tbadresa.Text = adresa;
            tbJMBG.Text = jmbg; 
        }

        private void btnocisti_Click(object sender, EventArgs e)
        {     
            tbIme.Text = "";
            tbPrezime.Text = "";
            tbKorisnickoIme.Text = "";
            tbJMBG.Text = "";
            tbemail.Text = "";
            tbbrTel.Text = "";
            tbadresa.Text = "";
        }
    }
}
