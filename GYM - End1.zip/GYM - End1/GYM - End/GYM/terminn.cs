﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GYM
{
    public partial class terminn : UserControl
    {
        GymEntities10 vezasaBazom;
        public terminn()
        {
            InitializeComponent();
            vezasaBazom = new GymEntities10();
            popuniTabelu();
            this.Dock = DockStyle.Fill;
            popuniTabelu1();
        }
      
        private void button1_Click(object sender, EventArgs e)
        {
            dateTimePicker1.CustomFormat = "yyyy MM dddd";
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            cbVreme.Items.Add(cbVreme);
            cbTip.Items.Add(cbTip);
            SqlConnection con = new SqlConnection("data source =AMINA; initial catalog = Gym; integrated security = True; MultipleActiveResultSets = True; App = EntityFramework & quot");
            try
            {
                con.Open();
                SqlCommand sda = new SqlCommand("INSERT INTO termin  (datum, vreme, Tiptreninga,ImeiPrezime,arhivirano) VALUES ('" + dateTimePicker1.Text + "', '" + cbVreme.Text + "','" + cbTip.Text + "', '" +comboBox1.Text + "', '0'); ", con);
                sda.ExecuteNonQuery();
                MessageBox.Show("Uspešno");
                con.Close(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void popuniTabelu()
        {
            List<termin> termini = vezasaBazom.termins.Where(t => t.arhivirano == 0).ToList();
            dtgwPrikazTermina.DataSource = null;
            dtgwPrikazTermina.DataSource = termini;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Today;
        }
        private void popuniTabelu1()
        {
            var prikazati = " ";

            var clanovi = new List<string>();
            List<osoba> lista = vezasaBazom.osobas.ToList();
            List<clan> lista2 = vezasaBazom.clans.ToList();
            List<string> zaPrikaz = new List<string>();

            foreach (var osoba in lista)
            {
                foreach (var cl in lista2)
                {
                    if (osoba.JMBG == cl.IDClana)
                    {
                        prikazati = osoba.Ime + " " + osoba.Prezime;
                        zaPrikaz.Add(prikazati);

                    }
                    else
                    {
                        continue;
                    }
                }
            }
            comboBox1.DataSource = zaPrikaz;
        }
    }
}
