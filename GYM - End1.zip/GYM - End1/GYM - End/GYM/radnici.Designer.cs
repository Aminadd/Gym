﻿namespace GYM
{
    partial class radnici
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbIme = new System.Windows.Forms.TextBox();
            this.tbPrezime = new System.Windows.Forms.TextBox();
            this.tbbrTel = new System.Windows.Forms.TextBox();
            this.tbadresa = new System.Windows.Forms.TextBox();
            this.tbemail = new System.Windows.Forms.TextBox();
            this.tbJMBG = new System.Windows.Forms.TextBox();
            this.btnocisti = new System.Windows.Forms.Button();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnAzuriranje = new System.Windows.Forms.Button();
            this.btnObrisi = new System.Windows.Forms.Button();
            this.cbM = new System.Windows.Forms.RadioButton();
            this.cbZ = new System.Windows.Forms.RadioButton();
            this.radniciBox = new System.Windows.Forms.ListBox();
            this.lblKI = new System.Windows.Forms.Label();
            this.tbKorisnickoIme = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLozinka = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 208);
            this.label1.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ime:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 243);
            this.label2.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Prezime:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(-2, 278);
            this.label3.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Broj telefona:";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(330, 208);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Adresa:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(2, 327);
            this.label5.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 20);
            this.label5.TabIndex = 2;
            this.label5.Text = "Pol:";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(330, 284);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "JMBG:";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(330, 243);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 20);
            this.label9.TabIndex = 2;
            this.label9.Text = "Email:";
            // 
            // tbIme
            // 
            this.tbIme.Location = new System.Drawing.Point(124, 211);
            this.tbIme.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.tbIme.Name = "tbIme";
            this.tbIme.Size = new System.Drawing.Size(108, 23);
            this.tbIme.TabIndex = 3;
            // 
            // tbPrezime
            // 
            this.tbPrezime.Location = new System.Drawing.Point(124, 246);
            this.tbPrezime.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.tbPrezime.Name = "tbPrezime";
            this.tbPrezime.Size = new System.Drawing.Size(108, 23);
            this.tbPrezime.TabIndex = 3;
            // 
            // tbbrTel
            // 
            this.tbbrTel.Location = new System.Drawing.Point(124, 278);
            this.tbbrTel.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.tbbrTel.Name = "tbbrTel";
            this.tbbrTel.Size = new System.Drawing.Size(108, 23);
            this.tbbrTel.TabIndex = 3;
            // 
            // tbadresa
            // 
            this.tbadresa.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbadresa.Location = new System.Drawing.Point(474, 211);
            this.tbadresa.Name = "tbadresa";
            this.tbadresa.Size = new System.Drawing.Size(110, 23);
            this.tbadresa.TabIndex = 3;
            // 
            // tbemail
            // 
            this.tbemail.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbemail.Location = new System.Drawing.Point(474, 246);
            this.tbemail.Name = "tbemail";
            this.tbemail.Size = new System.Drawing.Size(110, 23);
            this.tbemail.TabIndex = 3;
            // 
            // tbJMBG
            // 
            this.tbJMBG.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbJMBG.Location = new System.Drawing.Point(474, 281);
            this.tbJMBG.Name = "tbJMBG";
            this.tbJMBG.Size = new System.Drawing.Size(110, 23);
            this.tbJMBG.TabIndex = 3;
            // 
            // btnocisti
            // 
            this.btnocisti.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnocisti.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnocisti.Location = new System.Drawing.Point(21, 541);
            this.btnocisti.Margin = new System.Windows.Forms.Padding(50);
            this.btnocisti.Name = "btnocisti";
            this.btnocisti.Size = new System.Drawing.Size(82, 40);
            this.btnocisti.TabIndex = 6;
            this.btnocisti.Text = "Ocisti";
            this.btnocisti.UseVisualStyleBackColor = true;
            this.btnocisti.Click += new System.EventHandler(this.btnocisti_Click);
            // 
            // btnDodaj
            // 
            this.btnDodaj.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnDodaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDodaj.Location = new System.Drawing.Point(170, 541);
            this.btnDodaj.Margin = new System.Windows.Forms.Padding(50);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(85, 40);
            this.btnDodaj.TabIndex = 6;
            this.btnDodaj.Text = "Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // btnAzuriranje
            // 
            this.btnAzuriranje.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAzuriranje.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAzuriranje.Location = new System.Drawing.Point(334, 541);
            this.btnAzuriranje.Margin = new System.Windows.Forms.Padding(50);
            this.btnAzuriranje.Name = "btnAzuriranje";
            this.btnAzuriranje.Size = new System.Drawing.Size(104, 40);
            this.btnAzuriranje.TabIndex = 6;
            this.btnAzuriranje.Text = "Ažuriranje";
            this.btnAzuriranje.UseVisualStyleBackColor = true;
            this.btnAzuriranje.Click += new System.EventHandler(this.btnAzuriranje_Click);
            // 
            // btnObrisi
            // 
            this.btnObrisi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnObrisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnObrisi.Location = new System.Drawing.Point(496, 541);
            this.btnObrisi.Margin = new System.Windows.Forms.Padding(50);
            this.btnObrisi.Name = "btnObrisi";
            this.btnObrisi.Size = new System.Drawing.Size(88, 40);
            this.btnObrisi.TabIndex = 6;
            this.btnObrisi.Text = "Obriši";
            this.btnObrisi.UseVisualStyleBackColor = true;
            this.btnObrisi.Click += new System.EventHandler(this.btnObrisi_Click);
            // 
            // cbM
            // 
            this.cbM.AutoSize = true;
            this.cbM.Location = new System.Drawing.Point(124, 329);
            this.cbM.Name = "cbM";
            this.cbM.Size = new System.Drawing.Size(41, 21);
            this.cbM.TabIndex = 7;
            this.cbM.TabStop = true;
            this.cbM.Text = "M";
            this.cbM.UseVisualStyleBackColor = true;
            // 
            // cbZ
            // 
            this.cbZ.AutoSize = true;
            this.cbZ.Location = new System.Drawing.Point(193, 329);
            this.cbZ.Name = "cbZ";
            this.cbZ.Size = new System.Drawing.Size(39, 21);
            this.cbZ.TabIndex = 8;
            this.cbZ.TabStop = true;
            this.cbZ.Text = "Ž";
            this.cbZ.UseVisualStyleBackColor = true;
            // 
            // radniciBox
            // 
            this.radniciBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radniciBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radniciBox.FormattingEnabled = true;
            this.radniciBox.ItemHeight = 18;
            this.radniciBox.Location = new System.Drawing.Point(4, 4);
            this.radniciBox.Name = "radniciBox";
            this.radniciBox.Size = new System.Drawing.Size(618, 184);
            this.radniciBox.TabIndex = 9;
            this.radniciBox.Click += new System.EventHandler(this.radniciBox_Click);
            this.radniciBox.SelectedIndexChanged += new System.EventHandler(this.radniciBox_SelectedIndexChanged);
            // 
            // lblKI
            // 
            this.lblKI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblKI.AutoSize = true;
            this.lblKI.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKI.Location = new System.Drawing.Point(330, 323);
            this.lblKI.Name = "lblKI";
            this.lblKI.Size = new System.Drawing.Size(139, 20);
            this.lblKI.TabIndex = 11;
            this.lblKI.Text = "Korisnicko ime:";
            // 
            // tbKorisnickoIme
            // 
            this.tbKorisnickoIme.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbKorisnickoIme.Location = new System.Drawing.Point(474, 323);
            this.tbKorisnickoIme.Name = "tbKorisnickoIme";
            this.tbKorisnickoIme.Size = new System.Drawing.Size(110, 23);
            this.tbKorisnickoIme.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(330, 358);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Lozinka:";
            // 
            // txtLozinka
            // 
            this.txtLozinka.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLozinka.Location = new System.Drawing.Point(474, 358);
            this.txtLozinka.Name = "txtLozinka";
            this.txtLozinka.Size = new System.Drawing.Size(110, 23);
            this.txtLozinka.TabIndex = 13;
            // 
            // radnici
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.Controls.Add(this.txtLozinka);
            this.Controls.Add(this.tbKorisnickoIme);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblKI);
            this.Controls.Add(this.radniciBox);
            this.Controls.Add(this.cbZ);
            this.Controls.Add(this.cbM);
            this.Controls.Add(this.btnObrisi);
            this.Controls.Add(this.btnAzuriranje);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.btnocisti);
            this.Controls.Add(this.tbJMBG);
            this.Controls.Add(this.tbemail);
            this.Controls.Add(this.tbadresa);
            this.Controls.Add(this.tbbrTel);
            this.Controls.Add(this.tbPrezime);
            this.Controls.Add(this.tbIme);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "radnici";
            this.Size = new System.Drawing.Size(627, 612);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbIme;
        private System.Windows.Forms.TextBox tbPrezime;
        private System.Windows.Forms.TextBox tbbrTel;
        private System.Windows.Forms.TextBox tbadresa;
        private System.Windows.Forms.TextBox tbemail;
        private System.Windows.Forms.TextBox tbJMBG;
        private System.Windows.Forms.Button btnocisti;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnAzuriranje;
        private System.Windows.Forms.Button btnObrisi;
        private System.Windows.Forms.RadioButton cbM;
        private System.Windows.Forms.RadioButton cbZ;
        private System.Windows.Forms.ListBox radniciBox;
        private System.Windows.Forms.Label lblKI;
        private System.Windows.Forms.TextBox tbKorisnickoIme;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLozinka;
    }
}
